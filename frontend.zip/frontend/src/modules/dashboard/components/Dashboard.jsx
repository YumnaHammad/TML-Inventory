import React from 'react';
import RoleBasedDashboard from '../../../components/RoleBasedDashboard';

const Dashboard = () => {
  return <RoleBasedDashboard />;
};

export default Dashboard;
