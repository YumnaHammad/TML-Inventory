import React from 'react';
import { LoginForm } from '../modules';

const Login = () => {
  return <LoginForm />;
};

export default Login;