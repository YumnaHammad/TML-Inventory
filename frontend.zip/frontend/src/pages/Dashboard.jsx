import React from 'react';
import { Dashboard as DashboardComponent } from '../modules';

const Dashboard = () => {
  return <DashboardComponent />;
};

export default Dashboard;